import React, { useState, useRef, useEffect }from 'react'
import ChatHeader from './components/ChatHeader'
import ChatInput from './components/ChatInput'
import ChatMessage from './components/ChatMessage'
import ThinkingSkeleton from './components/ThinkingSkeleton'
import EmptyState from './components/EmptyState.jsx'
import { useChatStream } from './hooks/useChatStream.js'

export default function App() {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);
  const scrollContainerRef = useRef(null);

  const {
    messages,
    isLoading,
    isSearching,
    currentSearchQuery,
    sendMessage,
    resetChat,
  } = useChatStream();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

   const handleSubmit = async () => {
    if (!input.trim() || isLoading) return;
    
    const userMessage = input.trim();
    setInput('');
    await sendMessage(userMessage);
  };

  const handleNewChat = () => {
    setInput('');
    resetChat();
  };

  return (
     <div className="flex flex-col h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800">
      <ChatHeader onNewChat={handleNewChat} />

      {/* Messages Container */}
      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto px-4 py-8"
      >
        <div className="max-w-4xl mx-auto">
          {messages.length === 0 ? (
            <EmptyState />
          ) : (
            <>
              {messages.map((msg, idx) => (
                <ChatMessage
                  key={idx}
                  message={msg.content}
                  isUser={msg.role === 'user'}
                  sources={msg.sources}
                  isSearching={msg.role === 'assistant' && idx === messages.length - 1 && isSearching}
                  searchQuery={currentSearchQuery}
                />
              ))}
              {isLoading && messages[messages.length - 1]?.role === 'user' && <ThinkingSkeleton />}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      <ChatInput
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onSubmit={handleSubmit}
        isLoading={isLoading}
      />
    </div>
  )
}
