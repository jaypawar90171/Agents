import React from 'react';
import { extractHostname } from '../utils/formatUrl';

const SourceBadge = ({ url }) => {
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg hover:border-blue-400 dark:hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-gray-600 transition-colors group"
    >
      <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
      <span className="max-w-[200px] truncate text-gray-700 dark:text-gray-300 group-hover:text-blue-600 dark:group-hover:text-blue-400">
        {extractHostname(url)}
      </span>
    </a>
  );
};

export default SourceBadge;