import React from 'react';

const ThinkingSkeleton = () => {
  return (
    <div className="flex justify-start mb-6">
      <div className="max-w-3xl w-full">
        <div className="rounded-2xl px-6 py-4 bg-gray-100 dark:bg-gray-800">
          <div className="space-y-3">
            <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded animate-pulse w-3/4"></div>
            <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded animate-pulse w-full"></div>
            <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded animate-pulse w-5/6"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThinkingSkeleton;