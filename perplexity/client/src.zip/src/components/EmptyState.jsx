import React from 'react';
import { Sparkles } from 'lucide-react';

const EmptyState = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center py-20">
      <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mb-6">
        <Sparkles className="w-10 h-10 text-white" />
      </div>
      <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-3">
        How can I help you today?
      </h2>
      <p className="text-gray-500 dark:text-gray-400 max-w-md">
        Ask me anything. I'll search the web and provide you with accurate, sourced answers.
      </p>
    </div>
  );
};

export default EmptyState;