import React from 'react';
import { Sparkles, RefreshCw } from 'lucide-react';
import Button from './Button.jsx';

const ChatHeader = ({ onNewChat }) => {
  return (
    <header className="border-b border-gray-200 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl">
      <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">AI Assistant</h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">Powered by Web Search</p>
          </div>
        </div>
        <Button onClick={onNewChat} variant="secondary" className="gap-2">
          <RefreshCw className="w-4 h-4" />
          New Chat
        </Button>
      </div>
    </header>
  );
};

export default ChatHeader;