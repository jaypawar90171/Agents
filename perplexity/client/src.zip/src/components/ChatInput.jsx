import React from 'react';
import { Send } from 'lucide-react';
import Input from './Input';
import Button from './Button.jsx';

const ChatInput = ({ value, onChange, onSubmit, isLoading }) => {
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSubmit();
    }
  };

  return (
    <div className="border-t border-gray-200 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl">
      <div className="max-w-4xl mx-auto px-4 py-4">
        <div className="relative">
          <Input
            value={value}
            onChange={onChange}
            onKeyPress={handleKeyPress}
            placeholder="Ask anything..."
            disabled={isLoading}
            className="pr-14"
          />
          <Button
            onClick={onSubmit}
            disabled={isLoading || !value.trim()}
            variant="primary"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
        <p className="text-xs text-center text-gray-400 dark:text-gray-500 mt-3">
          Powered by AI with real-time web search
        </p>
      </div>
    </div>
  );
};

export default ChatInput;