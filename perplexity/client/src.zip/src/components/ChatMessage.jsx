import React from 'react';
import { Search, Globe } from 'lucide-react';
import SourceBadge from './SourceBadge';

const ChatMessage = ({ message, isUser, sources, isSearching, searchQuery }) => {
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-6`}>
      <div className={`max-w-3xl ${isUser ? 'w-auto' : 'w-full'}`}>
        {/* Search Indicator */}
        {!isUser && isSearching && (
          <div className="mb-3 flex items-center gap-2 text-sm text-blue-600 dark:text-blue-400">
            <Search className="w-4 h-4 animate-pulse" />
            <span className="animate-pulse">Searching: {searchQuery}</span>
          </div>
        )}
        
        {/* Message Bubble */}
        <div
          className={`rounded-2xl px-6 py-4 ${
            isUser
              ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white ml-auto'
              : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100'
          }`}
        >
          <p className="whitespace-pre-wrap leading-relaxed">{message}</p>
        </div>

        {/* Sources */}
        {sources && sources.length > 0 && (
          <div className="mt-3 space-y-2">
            <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
              <Globe className="w-3 h-3" />
              <span>Sources</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {sources.map((url, idx) => (
                <SourceBadge key={idx} url={url} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatMessage;